import 'package:hive/hive.dart';
part 'event.g.dart';

@HiveType(typeId: 1)
class Event extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String description;

  @HiveField(3)
  String location;

  @HiveField(4)
  DateTime dateTime;

  @HiveField(5)
  int? notificationId;

  @HiveField(6)
  int? reminderMinutes;

  Event({
    required this.id,
    required this.title,
    required this.description,
    required this.location,
    required this.dateTime,
    this.notificationId,
    this.reminderMinutes,
  });
}
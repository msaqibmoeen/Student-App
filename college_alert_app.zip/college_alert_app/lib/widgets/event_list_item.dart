import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/event.dart';
import '../screens/event_detail_screen.dart';
import '../ui/app_theme.dart';
import 'premium_card.dart';

class EventListItem extends StatelessWidget {
  final Event event;
  const EventListItem({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('EEE, d MMM').format(event.dateTime);
    final timeStr = DateFormat('h:mm a').format(event.dateTime);
    final hasReminder = event.notificationId != null;

    return PremiumCard(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => EventDetailScreen(event: event)),
          );
        },
        child: Row(
          children: [
            _LeadingBadge(hasReminder: hasReminder),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(event.title,
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 10,
                    runSpacing: 8,
                    children: [
                      _MetaChip(icon: Icons.calendar_today, text: dateStr),
                      _MetaChip(icon: Icons.access_time, text: timeStr),
                      _MetaChip(icon: Icons.location_on, text: event.location),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right, color: AppColors.subtext),
          ],
        ),
      ),
    );
  }
}

class _LeadingBadge extends StatelessWidget {
  final bool hasReminder;
  const _LeadingBadge({required this.hasReminder});

  @override
  Widget build(BuildContext context) {
    final gradient = hasReminder
        ? const LinearGradient(
      colors: [AppColors.primary, AppColors.secondary],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    )
        : const LinearGradient(
      colors: [AppColors.surface2, AppColors.surface],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );

    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: gradient,
        boxShadow: hasReminder
            ? const [
          BoxShadow(
            color: Color(0x223D5AFE),
            blurRadius: 16,
            offset: Offset(0, 10),
          )
        ]
            : const [],
      ),
      child: Icon(
        hasReminder ? Icons.notifications_active : Icons.event,
        color: hasReminder ? Colors.white : AppColors.subtext,
        size: 22,
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String text;

  const _MetaChip({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.outline),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: AppColors.subtext),
          const SizedBox(width: 6),
          Text(
            text,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w700,
              color: AppColors.text,
            ),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/event.dart';
import '../screens/event_detail_screen.dart';

class EventCard extends StatelessWidget {
  final Event event;
  const EventCard({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('d MMM yyyy').format(event.dateTime);
    final timeStr = DateFormat('h:mm a').format(event.dateTime);

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(
          event.notificationId == null
              ? Icons.event
              : Icons.notifications_active,
        ),
        title: Text(event.title),
        subtitle: Text('$dateStr • $timeStr\n${event.location}'),
        isThreeLine: true,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => EventDetailScreen(event: event)),
          );
        },
      ),
    );
  }
}
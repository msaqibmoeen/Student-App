import 'package:flutter/material.dart';
import '../ui/app_theme.dart';

Future<int?> showReminderSheet(BuildContext context) {
  final customController = TextEditingController();

  return showModalBottomSheet<int>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    backgroundColor: AppColors.white,
    builder: (ctx) {
      return Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 8,
          bottom: 16 + MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Set reminder',
                style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 12),
            ListTile(
              title: const Text('10 minutes before'),
              leading: const Icon(Icons.timer_10),
              onTap: () => Navigator.pop(ctx, 10),
            ),
            ListTile(
              title: const Text('30 minutes before'),
              leading: const Icon(Icons.timer_10),
              onTap: () => Navigator.pop(ctx, 30),
            ),
            ListTile(
              title: const Text('60 minutes before'),
              leading: const Icon(Icons.schedule),
              onTap: () => Navigator.pop(ctx, 60),
            ),
            const Divider(),
            TextField(
              controller: customController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Custom minutes before',
                hintText: 'e.g., 90',
              ),
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: FilledButton(
                onPressed: () {
                  final raw = customController.text.trim();
                  final v = int.tryParse(raw);
                  if (v == null || v <= 0) {
                    ScaffoldMessenger.of(ctx).showSnackBar(
                      const SnackBar(content: Text('Enter a valid number > 0')),
                    );
                    return;
                  }
                  Navigator.pop(ctx, v);
                },
                child: const Text('Set custom reminder'),
              ),
            ),
            const SizedBox(height: 6),
          ],
        ),
      );
    },
  ).whenComplete(() => customController.dispose());
}
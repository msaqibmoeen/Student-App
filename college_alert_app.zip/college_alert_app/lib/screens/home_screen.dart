import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/event_provider.dart';
import '../ui/app_theme.dart';
import '../widgets/empty_state.dart';
import '../widgets/event_list_item.dart';
import 'add_edit_event_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EventProvider>();
    final events = provider.events;

    return Scaffold(
      appBar: AppBar(
        title: const Text('College Alert'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: () => provider.loadEvents(),
            icon: const Icon(Icons.refresh),
          ),
          const SizedBox(width: 6),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 2,
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddEditEventScreen()),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('New Event'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) {
                  provider.setSearchQuery(v);
                  setState(() {});
                },
                decoration: InputDecoration(
                  hintText: 'Search by title or location',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: (_searchCtrl.text.trim().isEmpty)
                      ? null
                      : IconButton(
                    tooltip: 'Clear',
                    onPressed: () {
                      _searchCtrl.clear();
                      provider.setSearchQuery('');
                      setState(() {});
                    },
                    icon: const Icon(Icons.close),
                  ),
                ),
              ),
            ),
            Expanded(
              child: provider.loading
                  ? const Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: CircularProgressIndicator(strokeWidth: 2.6),
                ),
              )
                  : events.isEmpty
                  ? EmptyState(
                title: provider.query.trim().isEmpty
                    ? 'No events yet'
                    : 'No results',
                subtitle: provider.query.trim().isEmpty
                    ? 'Create your first campus event and set reminders.'
                    : 'Try another keyword or check spelling.',
                onAction: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AddEditEventScreen(),
                    ),
                  );
                },
              )
                  : ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                itemCount: events.length,
                separatorBuilder: (_, __) =>
                const SizedBox(height: 12),
                itemBuilder: (_, i) =>
                    EventListItem(event: events[i]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
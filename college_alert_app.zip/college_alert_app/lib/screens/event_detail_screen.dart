import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/event.dart';
import '../providers/event_provider.dart';
import '../ui/app_theme.dart';
import '../widgets/premium_card.dart';
import '../widgets/section_header.dart';
import '../widgets/reminder_sheet.dart';
import 'add_edit_event_screen.dart';

class EventDetailScreen extends StatelessWidget {
  final Event event;
  const EventDetailScreen({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    context.watch<EventProvider>();

    final dateStr = DateFormat('EEEE, d MMMM yyyy').format(event.dateTime);
    final timeStr = DateFormat('h:mm a').format(event.dateTime);

    final scheduled = event.notificationId != null;
    final reminderText = scheduled
        ? 'Scheduled (${event.reminderMinutes} min before)'
        : 'Not scheduled';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Event'),
        actions: [
          IconButton(
            tooltip: 'Edit',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => AddEditEventScreen(event: event)),
              );
            },
            icon: const Icon(Icons.edit),
          ),
          IconButton(
            tooltip: 'Delete',
            onPressed: () async {
              final ok = await _confirmDelete(context);
              if (ok == true && context.mounted) {
                await context.read<EventProvider>().deleteEvent(event);
                if (context.mounted) Navigator.pop(context);
              }
            },
            icon: const Icon(Icons.delete_outline),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          children: [
            Text(event.title, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 14),

            PremiumCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(
                    title: 'Details',
                    subtitle: 'Date, time and location',
                  ),
                  const SizedBox(height: 12),
                  _InfoRow(icon: Icons.calendar_today, title: 'Date', value: dateStr),
                  const SizedBox(height: 10),
                  _InfoRow(icon: Icons.access_time, title: 'Time', value: timeStr),
                  const SizedBox(height: 10),
                  _InfoRow(icon: Icons.location_on, title: 'Location', value: event.location),
                ],
              ),
            ),

            const SizedBox(height: 12),
            PremiumCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: 'Description', subtitle: 'Event notes'),
                  const SizedBox(height: 10),
                  Text(event.description, style: Theme.of(context).textTheme.bodyLarge),
                ],
              ),
            ),

            const SizedBox(height: 12),
            PremiumCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SectionHeader(
                    title: 'Reminder',
                    subtitle: reminderText,
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: scheduled ? const Color(0xFFEFF6FF) : AppColors.surface,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: AppColors.outline),
                      ),
                      child: Text(
                        scheduled ? 'Active' : 'Off',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: scheduled ? AppColors.primary : AppColors.subtext,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // WRAP content buttons (text-sized)
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      FilledButton.icon(
                        onPressed: () async {
                          final minutes = await showReminderSheet(context);
                          if (minutes == null) return;

                          final err = await context
                              .read<EventProvider>()
                              .scheduleReminder(event: event, minutesBefore: minutes);

                          if (!context.mounted) return;
                          if (err != null) {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(SnackBar(content: Text(err)));
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Reminder scheduled')),
                            );
                          }
                        },
                        icon: const Icon(Icons.alarm_add, size: 18),
                        label: const Text('Set Reminder'),
                      ),
                      OutlinedButton.icon(
                        onPressed: scheduled
                            ? () async {
                          await context.read<EventProvider>().cancelReminder(event);
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Reminder cancelled')),
                          );
                        }
                            : null,
                        icon: const Icon(Icons.notifications_off, size: 18),
                        label: const Text('Cancel'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool?> _confirmDelete(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete event?'),
        content: const Text('This will permanently remove the event and its reminder.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _InfoRow({required this.icon, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.outline),
          ),
          child: Icon(icon, size: 20, color: AppColors.subtext),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: AppColors.subtext,
                ),
              ),
              const SizedBox(height: 2),
              Text(value, style: Theme.of(context).textTheme.bodyLarge),
            ],
          ),
        ),
      ],
    );
  }
}
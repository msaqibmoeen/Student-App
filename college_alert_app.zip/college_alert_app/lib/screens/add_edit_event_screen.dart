import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/event.dart';
import '../providers/event_provider.dart';
import '../ui/app_theme.dart';
import '../widgets/premium_card.dart';
import '../widgets/section_header.dart';

class AddEditEventScreen extends StatefulWidget {
  final Event? event;
  const AddEditEventScreen({super.key, this.event});

  @override
  State<AddEditEventScreen> createState() => _AddEditEventScreenState();
}

class _AddEditEventScreenState extends State<AddEditEventScreen> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _title;
  late final TextEditingController _desc;
  late final TextEditingController _location;

  DateTime? _date;
  TimeOfDay? _time;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.event;
    _title = TextEditingController(text: e?.title ?? '');
    _desc = TextEditingController(text: e?.description ?? '');
    _location = TextEditingController(text: e?.location ?? '');

    if (e != null) {
      _date = DateTime(e.dateTime.year, e.dateTime.month, e.dateTime.day);
      _time = TimeOfDay(hour: e.dateTime.hour, minute: e.dateTime.minute);
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _location.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.event != null;

    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Edit Event' : 'New Event')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          children: [
            Text(
              editing ? 'Update your event' : 'Create a new event',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 14),

            PremiumCard(
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    const SectionHeader(
                      title: 'Event Info',
                      subtitle: 'Title, description and location',
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _title,
                      decoration: const InputDecoration(
                        labelText: 'Title',
                        prefixIcon: Icon(Icons.title),
                      ),
                      validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Title is required' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _desc,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        labelText: 'Description',
                        alignLabelWithHint: true,
                        prefixIcon: Icon(Icons.notes),
                      ),
                      validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Description is required' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _location,
                      decoration: const InputDecoration(
                        labelText: 'Location',
                        prefixIcon: Icon(Icons.location_on),
                      ),
                      validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Location is required' : null,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),
            PremiumCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: 'Schedule', subtitle: 'Pick date and time'),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _PickButton(
                          icon: Icons.calendar_today,
                          label: _date == null
                              ? 'Pick Date'
                              : DateFormat('d MMM yyyy').format(_date!),
                          onTap: _pickDate,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _PickButton(
                          icon: Icons.access_time,
                          label: _time == null ? 'Pick Time' : _time!.format(context),
                          onTap: _pickTime,
                        ),
                      ),
                    ],
                  ),
                  if (_date == null || _time == null) ...[
                    const SizedBox(height: 10),
                    Text(
                      'Date and time are required',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Text-sized button (not full width)
            Align(
              alignment: Alignment.centerLeft,
              child: FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2.2),
                )
                    : const Icon(Icons.save, size: 18),
                label: Text(editing ? 'Update Event' : 'Save Event'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final initial = _date ?? DateTime(now.year, now.month, now.day);

    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 5),
      initialDate: initial,
    );

    if (picked != null) {
      setState(() => _date = DateTime(picked.year, picked.month, picked.day));
    }
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _time ?? TimeOfDay.now(),
    );
    if (picked != null) setState(() => _time = picked);
  }

  Future<void> _save() async {
    final valid = _formKey.currentState?.validate() ?? false;
    if (!valid) return;

    if (_date == null || _time == null) {
      setState(() {});
      return;
    }

    setState(() => _saving = true);

    final dt = DateTime(
      _date!.year,
      _date!.month,
      _date!.day,
      _time!.hour,
      _time!.minute,
    );

    final provider = context.read<EventProvider>();

    if (widget.event == null) {
      await provider.addEvent(
        title: _title.text.trim(),
        description: _desc.text.trim(),
        location: _location.text.trim(),
        dateTime: dt,
      );
    } else {
      final e = widget.event!;
      e.title = _title.text.trim();
      e.description = _desc.text.trim();
      e.location = _location.text.trim();
      e.dateTime = dt;
      await provider.updateEvent(e);
    }

    if (!mounted) return;
    setState(() => _saving = false);
    Navigator.pop(context);
  }
}

class _PickButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _PickButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Ink(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.outline),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: AppColors.subtext),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.bodyLarge,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const Icon(Icons.chevron_right, color: AppColors.subtext),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'ui/app_theme.dart';

class CollegeAlertApp extends StatelessWidget {
  const CollegeAlertApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'College Alert',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: const HomeScreen(),
    );
  }
}
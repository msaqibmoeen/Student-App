import 'package:hive_flutter/hive_flutter.dart';
import '../models/event.dart';

class HiveService {
  static const String eventsBoxName = 'eventsBox';

  static Future<void> init() async {
    await Hive.initFlutter();
  }

  static void registerAdapters() {
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(EventAdapter());
    }
  }

  static Future<void> openBoxes() async {
    await Hive.openBox<Event>(eventsBoxName);
  }

  static Box<Event> eventsBox() => Hive.box<Event>(eventsBoxName);
}
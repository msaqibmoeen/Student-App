import 'dart:math';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/event.dart';
import '../services/hive_service.dart';
import '../services/notification_service.dart';

class EventProvider extends ChangeNotifier {
  final _uuid = const Uuid();
  final _rng = Random();

  List<Event> _events = [];
  String _query = '';
  bool _loading = true;

  bool get loading => _loading;
  String get query => _query;

  List<Event> get events {
    final filtered = _events.where((e) {
      if (_query.trim().isEmpty) return true;
      final q = _query.toLowerCase();
      return e.title.toLowerCase().contains(q) ||
          e.location.toLowerCase().contains(q);
    }).toList();

    filtered.sort((a, b) => a.dateTime.compareTo(b.dateTime));
    return filtered;
  }

  Future<void> loadEvents() async {
    _loading = true;
    notifyListeners();

    final box = HiveService.eventsBox();
    _events = box.values.toList();

    _loading = false;
    notifyListeners();
  }

  void setSearchQuery(String q) {
    _query = q;
    notifyListeners();
  }

  Future<void> addEvent({
    required String title,
    required String description,
    required String location,
    required DateTime dateTime,
  }) async {
    final event = Event(
      id: _uuid.v4(),
      title: title,
      description: description,
      location: location,
      dateTime: dateTime,
    );

    final box = HiveService.eventsBox();
    await box.put(event.id, event);

    _events.add(event);
    notifyListeners();
  }

  Future<void> updateEvent(Event event) async {
    await event.save();
    notifyListeners();
  }

  Future<void> deleteEvent(Event event) async {
    if (event.notificationId != null) {
      await NotificationService.instance.cancel(event.notificationId!);
    }
    await event.delete();
    _events.removeWhere((e) => e.id == event.id);
    notifyListeners();
  }

  int _generateNotificationId() => _rng.nextInt(2000000000) + 1;

  Future<String?> scheduleReminder({
    required Event event,
    required int minutesBefore,
  }) async {
    final scheduledAt =
    event.dateTime.subtract(Duration(minutes: minutesBefore));

    if (scheduledAt.isBefore(DateTime.now())) {
      return 'Reminder time is in the past. Choose a smaller offset or a future event time.';
    }

    if (event.notificationId != null) {
      await NotificationService.instance.cancel(event.notificationId!);
    }

    final nid = _generateNotificationId();

    await NotificationService.instance.scheduleEventReminder(
      notificationId: nid,
      scheduledAt: scheduledAt,
      title: 'College Alert',
      body:
      '${event.title} starts at ${TimeOfDay.fromDateTime(event.dateTime).format(_dummyContext)} in ${event.location}',
    );

    event.notificationId = nid;
    event.reminderMinutes = minutesBefore;
    await event.save();

    notifyListeners();
    return null;
  }

  Future<void> cancelReminder(Event event) async {
    final nid = event.notificationId;
    if (nid != null) {
      await NotificationService.instance.cancel(nid);
    }
    event.notificationId = null;
    event.reminderMinutes = null;
    await event.save();
    notifyListeners();
  }
}

// Small helper for formatting without needing BuildContext everywhere.
// (Only for formatting text; UI uses intl anyway.)
final _dummyContext = _FakeBuildContext();

class _FakeBuildContext implements BuildContext {
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}
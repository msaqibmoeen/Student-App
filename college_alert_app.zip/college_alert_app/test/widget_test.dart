import 'package:flutter_test/flutter_test.dart';
import 'package:college_alert_app/app.dart';

void main() {
  testWidgets('App loads', (WidgetTester tester) async {
    await tester.pumpWidget(const CollegeAlertApp());
    expect(find.text('College Alert'), findsOneWidget);
  });
}